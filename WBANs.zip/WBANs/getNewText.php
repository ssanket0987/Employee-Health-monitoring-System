<?php
// generate some new text
$newText = 78;

// return the new text as a JSON response
echo json_encode($newText);

?>